function printErr(elemId,errMsg) 
{
document.getElementById(elemId).innerHTML = errMsg;
}

function validate()

{

	var name = document.getElementById("name").value.trim();
	var email =document.getElementById("email").value.trim();
	var city  =document.getElementById("city").value.trim();
	var mobileno =document.getElementById("cno").value.trim();
	var hobby   = document.form1.cycling.value;
	var gender  = document.form1.gender.value;
	 var dob     = document.getElementById("dob").value;
	var va li=true;
	if(name == " ")
	{
		printErr("err1","enter name please");
		vali = false;
	} 
	else
	{
		var regex0=/^[a-z ,.'-]+$/i;
		if(regex0.test(name) === false)
		{
		printErr("err1","dont enter other than alphabet");
		vali = false;
	    }
	    else
	    {
	    	printErr("err1","");
	    }
	}
	if(email=="")
	{
		printErr("err2","enter your id");
		vali=false;
	}  
	else
	{
		var regex2=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;                
        if(regex2.test(email) === false) 
        {
            printErr("err2", "enter valid id");
            vali=false;
        } 
        else 
        {
            printErr("err2","");
            
        }
    }
	if(mobileno =="")
	{
		printErr("err3","enter your cell");
		vali=false;
	}  
	else
	{
		var regex3=/^\d{9}$/;
		if(regex3.test(mobileno) === false)
		{
			printErr("err3","enter your valid mobileno");
			vali=false;
		}	
		else
		{
			printErr("err3","");
		}
	}
	if(city == "")
	{
        printErr("err4","enter the city")
        vali=false;
	}
	else
	{
		var regex5=/^[a-z ,.'-]+$/i;
		if(regex5.test(name) === false)
		{
		printErr("err4","dont enter other than alphabet");
		vali=false;
	    }
	    else
	    {
	    	printErr("err4","");
	    }
	}
	if(dob=="")
	{
		printErr("err5","enter the dob");
		vali=false;
	}
	else
	{
		printErr("err5","");

	}
	if(gender=="")
	{
		printErr("err6","enter the gender");
		vali=false;
	}
	else
	{
		printErr("err6","");
	}
	if(hobby=="")
	{
		printErr("err7","enter the hobby");
		vali=false;
	}
	else
	{
		printErr("err7","");
	}
	return vali;

}