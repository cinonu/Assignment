function printErr(elemId,errMsg) 
{
document.getElementById(elemId).innerHTML = errMsg;
}
function validate()
{
	var name = document.getElementById("name").value.trim();
	var email =document.getElementById("emaiid").value.trim();
	var city  =document.getElementById("city").value.trim();
	var mobileno =document.getElementById("mono").value.trim();
	var hobby   = document.getElementById("hobby").value.trim();
	var gender  = document.form1.gender.value;
	var dob     = document.getElementById("dob").value;
	var vali=true;

	if(name == " ")
	{
		printErr("err1","enter name please");
		vali = false;
	} 
	else
	{
		var regex0=/^[a-z ,.'-]+$/i;
		if(regex0.test(name) === false)
		{
		printErr("err1","dont enter other than alphabet");
	    }
	    else
	    {
	    	printErr("err1","");
	    }
	}
	if(email=="")
	{
		printErr("err2","enter your id");
		vali=false;
	}  
	else
	{
		var regex2= /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;;                
        if(regex2.test(email) === false) 
        {
            printErr("err2", "enter valid id");
            vali=false;
        } 
        else 
        {
            printErr("err2", "");
            
        }
	}
	if(mobileno =="")
	{
		printErr("err3","enter your cell");
		vali=false;
	}  
	else
	{
		var regex3=/^\d{3}$/;
		if(regex3.test(mobileno) === false)
		{
			printErr("err3","enter your emailid");
			vali=false;
		}	
		else
		{
			printErr("err3","");
		}
	}
	if(city=="")
	{
		printErr("err4","enter your city")
		vali=false;
	}
	else
	{
		var regex4=/^[a-z ,.'-]+$/i;
		if(regex4.test(city) === false)
		{
		printErr("err4","dont enter other than alphabet");
		vali=false;
	    }
	    else
	    {
	    	printErr("err4","");
	    }
	}
	if(hobby == "")
	{
        printErr("err5","enter the hobby")
        vali=false;
	}
	else
	{
		var regex5=/^[a-z ,.'-]+$/i;
		if(regex5.test(name) === false)
		{
		printErr("err5","dont enter other than alphabet");
		vali=false;
	    }
	    else
	    {
	    	printErr("err5","");
	    }
	}
	if(dob=="")
	{
		printErr("err6","enter the dob")
		vali=false;
	}
	else
	{
		printErr("err6","")

	}
	return vali;

}